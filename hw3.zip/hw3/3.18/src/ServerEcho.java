import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerEcho {
	public static void main(String args[]) throwsIOException {
		ServerSocket serverSocket = newServerSocket(6013);
		Socket sock = serverSocket.accept();
		try {
			DataInputStream inStream = newDataInputStream(socket.getInputStream());
			DataOutputStream outStream = newDataOutputStream(socket.getOutputStream());
			while (true) {
				int read;
				byte[] buffer = new byte[2048];
				read = inStream.read(buffer);
				do {
					outStream.write(buffer, 0, read);
					read = inStream.read(buffer);
				} while (read != -1);
				outStream.flush();
			}
			serverSocket.close();
			socket.close();
		} 
		catch (IOException e) {				
			e.printStackTrace();
		}
	}
}