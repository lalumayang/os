import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public static void main(String args[]) throwsUnknownHostException, IOException {
		Socket sock = new Socket("localhost", 6013);
		DataInputStream inStream = newDataInputStream(socket.getInputStream());
		DataOutputStream outStream = newDataOutputStream(socket.getOutputStream());
		BufferedReader br = new BufferedReader(newInputStreamReader(System.in));
		do {
			String userText = br.readLine();
			if (userText != null && !userText.isEmpty()) {
				outStream.writeUTF(userText);
				outStream.flush();
			}
			String answer = inStream.readUTF();
			if (!answer.isEmpty()) {
				System.out.println(answer);
			}
		}
		while(!userText.trim().equalsIgnoreCase("finished"));
		socket.close();
	}
}